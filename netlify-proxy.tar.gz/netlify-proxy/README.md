# FreeProxy — Open-Source Client-Side Web Proxy

A clean, dark-themed, **100% client-side** web proxy powered by
[Scramjet](https://github.com/MercuryWorkshop/scramjet) and
[bare-mux](https://github.com/MercuryWorkshop/bare-mux). It is designed to be
dropped straight into a **free Netlify static deployment** — no server, no
build step.

## Files

| File           | Purpose                                                                 |
|----------------|-------------------------------------------------------------------------|
| `index.html`   | Dark, responsive search-engine-style UI. Loads CDN bundles.             |
| `script.js`    | Initialises the ScramjetController, registers the SW, sets up bare-mux. |
| `sw.js`        | Service Worker — intercepts `fetch` and routes via `scramjet.fetch()`.  |
| `netlify.toml` | Netlify headers (COOP/COEP isolation, SW MIME type & scope).            |

## How it works

1. **`index.html`** loads `bare-mux` and the Scramjet `scramjet.all.js` bundle
   from jsDelivr, then renders the search bar.
2. **`script.js`**:
   - Creates a `ScramjetController` pointing at the `.wasm`, `.all.js`, and
     `.sync.js` assets on the CDN, and calls `scramjet.init()`.
   - Registers `sw.js` as a Service Worker.
   - Opens a `BareMux.BareMuxConnection` and attaches the **libcurl Wisp
     transport** to a public Wisp server (`wss://wisp.mercuryworkshop.xyz/`).
   - On form submit, normalises the input to a full `https://` URL, encodes it
     with `__scramjet$config.encodeUrl()`, and sets `window.location.href`.
3. **`sw.js`** imports the Scramjet worker bundle, instantiates
   `ScramjetServiceWorker`, and on every `fetch` event proxies matching
   requests with `scramjet.fetch(event)`.

## Deploy to Netlify

### Option A — Drag & drop
1. Zip this folder (or just the 4 files).
2. Go to <https://app.netlify.com/drop> and drop the folder.
3. Done — your proxy is live over HTTPS (required for Service Workers).

### Option B — Git
1. Push this folder to a GitHub repo.
2. In Netlify: **Add new site → Import from Git** → pick the repo.
3. Leave build command empty and publish directory as `.`.

## Configuration

Edit the constants at the top of `script.js`:

- `WISP_URL` — point this at your **own** Wisp server for reliability/privacy.
  Public servers are best-effort and may be rate-limited or go down.
- `SCRAMJET_VERSION` / `BAREMUX_VERSION` / `LIBCURL_VERSION` — pinned CDN
  versions.
- `SEARCH_TEMPLATE` — default search engine for non-URL queries.

## Notes & limitations

- **HTTPS is mandatory.** Service Workers won't register over plain HTTP
  (except on `localhost`). Netlify serves HTTPS automatically.
- Public Wisp endpoints are shared and **not guaranteed**. For production,
  host your own [wisp-server-node](https://github.com/MercuryWorkshop/wisp-server-node).
- This project is for **legitimate uses** such as privacy, testing, and
  bypassing arbitrary browser restrictions. Respect the laws and terms of
  service that apply to you.

## License

Open source. Scramjet, bare-mux, and libcurl-transport are © Mercury Workshop
under their respective licenses.
