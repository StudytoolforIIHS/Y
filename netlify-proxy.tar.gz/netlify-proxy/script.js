/**
 * script.js — Client controller for the FreeProxy web app
 * ============================================================================
 * Responsibilities:
 *   1. Initialise the ScramjetController and point it at the .wasm / .all.js /
 *      .sync.js assets on the jsDelivr CDN.
 *   2. Register the Service Worker (sw.js) that performs the interception.
 *   3. Open a BareMuxConnection and attach a public Wisp transport WebSocket
 *      so the backend proxying actually has somewhere to tunnel traffic.
 *   4. Handle the search form: take the user's input, normalise it into a
 *      fully-qualified URL, encode it with __scramjet$config.encodeUrl(), and
 *      navigate the page to the resulting proxy path.
 *
 * Everything here runs strictly in the browser — no server code involved.
 * ============================================================================
 */

"use strict";

/* ---------------------------------------------------------------------------
 * Configuration
 * ------------------------------------------------------------------------- */

const CDN = "https://cdn.jsdelivr.net/npm";
const SCRAMJET_VERSION = "1.1.0";
const BAREMUX_VERSION = "2.1.7";
const LIBCURL_VERSION = "2.0.5";

// Scramjet asset map — served directly from jsDelivr.
const SCRAMJET_FILES = {
  wasm: `${CDN}/@mercuryworkshop/scramjet@${SCRAMJET_VERSION}/dist/scramjet.wasm.wasm`,
  all: `${CDN}/@mercuryworkshop/scramjet@${SCRAMJET_VERSION}/dist/scramjet.all.js`,
  sync: `${CDN}/@mercuryworkshop/scramjet@${SCRAMJET_VERSION}/dist/scramjet.sync.js`,
};

// bare-mux worker bundle (the dedicated worker that owns the transport).
const BAREMUX_WORKER = `${CDN}/@mercuryworkshop/bare-mux@${BAREMUX_VERSION}/dist/worker.js`;

// libcurl Wisp transport (ESM module) used by bare-mux.
const LIBCURL_TRANSPORT = `${CDN}/@mercuryworkshop/libcurl-transport@${LIBCURL_VERSION}/dist/index.mjs`;

// Public Wisp server. Mercury Workshop hosts an open one; swap for your own
// (e.g. a self-hosted wisp-server-node) in production for reliability.
const WISP_URL = "wss://wisp.mercuryworkshop.xyz/";

// Default search engine — %s is replaced with the URL-encoded query.
const SEARCH_TEMPLATE = "https://www.google.com/search?q=%s";

/* ---------------------------------------------------------------------------
 * DOM references
 * ------------------------------------------------------------------------- */

const form = document.getElementById("search-form");
const input = document.getElementById("address-input");
const goButton = document.getElementById("go-button");
const status = document.getElementById("status");
const quickLinks = document.querySelector(".quick-links");

/* ---------------------------------------------------------------------------
 * Status helpers
 * ------------------------------------------------------------------------- */

function setStatus(message, { error = false, loading = false } = {}) {
  status.classList.toggle("error", error);
  status.innerHTML = "";
  if (loading) {
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    status.appendChild(spinner);
  }
  status.appendChild(document.createTextNode(message));
}

function clearStatus() {
  status.classList.remove("error");
  status.textContent = "";
}

/* ---------------------------------------------------------------------------
 * 1. Scramjet controller
 * ------------------------------------------------------------------------- */

// `$scramjetLoadController` is provided by the scramjet.all.js bundle loaded
// from the CDN in index.html.
const { ScramjetController } = $scramjetLoadController();

const scramjet = new ScramjetController({
  files: SCRAMJET_FILES,
});

// Publishes the Scramjet config (including the asset map) so the Service
// Worker can read it via scramjet.loadConfig().
scramjet.init();

/* ---------------------------------------------------------------------------
 * 2. Service Worker registration
 * ------------------------------------------------------------------------- */

const SW_ALLOWED_HOSTNAMES = ["localhost", "127.0.0.1"];

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) {
    if (
      location.protocol !== "https:" &&
      !SW_ALLOWED_HOSTNAMES.includes(location.hostname)
    ) {
      throw new Error(
        "Service workers require HTTPS (Netlify serves HTTPS by default)."
      );
    }
    throw new Error("This browser does not support service workers.");
  }

  // Register at the app root so the SW scope covers the proxy paths.
  await navigator.serviceWorker.register("./sw.js", { scope: "./" });
  await navigator.serviceWorker.ready;
}

/* ---------------------------------------------------------------------------
 * 3. bare-mux transport
 * ------------------------------------------------------------------------- */

// `BareMux` is the global exposed by bare-mux/dist/index.js (loaded in
// index.html). The connection spins up a shared worker that owns the transport.
const connection = new BareMux.BareMuxConnection(BAREMUX_WORKER);

let transportReady = false;

async function ensureTransport() {
  if (transportReady) return;

  // Only (re)set the transport if it is not already the libcurl/Wisp one.
  const current = await connection.getTransport();
  if (current !== LIBCURL_TRANSPORT) {
    await connection.setTransport(LIBCURL_TRANSPORT, [{ wisp: WISP_URL }]);
  }
  transportReady = true;
}

/* ---------------------------------------------------------------------------
 * 4. URL normalisation
 * ------------------------------------------------------------------------- */

/**
 * Turn arbitrary user input into a fully-qualified URL.
 *  - Valid URL              -> used as-is
 *  - "example.com/path"     -> prefixed with https://
 *  - Anything else          -> treated as a search query
 *
 * @param {string} value Raw text from the search box.
 * @returns {string} A fully-qualified https(s):// URL.
 */
function normaliseToUrl(value) {
  const trimmed = value.trim();

  // Already a complete URL?
  try {
    const url = new URL(trimmed);
    if (url.protocol === "http:" || url.protocol === "https:") {
      return url.toString();
    }
  } catch (_) {
    /* not a full URL — keep trying */
  }

  // Looks like a bare domain (contains a dot, no spaces)? Prefix https://.
  if (/^[^\s]+\.[^\s]+$/.test(trimmed)) {
    try {
      const url = new URL(`https://${trimmed}`);
      if (url.hostname.includes(".")) {
        return url.toString();
      }
    } catch (_) {
      /* fall through to search */
    }
  }

  // Otherwise treat it as a search query.
  return SEARCH_TEMPLATE.replace("%s", encodeURIComponent(trimmed));
}

/* ---------------------------------------------------------------------------
 * Navigation: encode via __scramjet$config and go
 * ------------------------------------------------------------------------- */

/**
 * Encode a fully-qualified URL into a Scramjet proxy path and navigate there.
 * @param {string} fullUrl
 */
function encodeUrl(fullUrl) {
  // Preferred: the global config encoder injected by scramjet.all.js.
  if (
    typeof __scramjet$config !== "undefined" &&
    typeof __scramjet$config.encodeUrl === "function"
  ) {
    return __scramjet$config.encodeUrl(fullUrl);
  }
  // Fallback: the controller instance also exposes encodeUrl in 1.x/2.x.
  if (typeof scramjet.encodeUrl === "function") {
    return scramjet.encodeUrl(fullUrl);
  }
  throw new Error("Scramjet encodeUrl is unavailable — bundle failed to load.");
}

async function navigate(rawValue) {
  const fullUrl = normaliseToUrl(rawValue);

  goButton.disabled = true;
  setStatus("Connecting to proxy…", { loading: true });

  try {
    await registerServiceWorker();
    await ensureTransport();

    const encoded = encodeUrl(fullUrl);
    setStatus(`Loading ${fullUrl} …`, { loading: true });

    // Send the page to the proxied destination.
    window.location.href = encoded;
  } catch (err) {
    console.error(err);
    setStatus(err && err.message ? err.message : String(err), { error: true });
    goButton.disabled = false;
  }
}

/* ---------------------------------------------------------------------------
 * Event wiring
 * ------------------------------------------------------------------------- */

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const value = input.value;
  if (!value.trim()) {
    setStatus("Type a URL or search term to begin.", { error: true });
    input.focus();
    return;
  }
  navigate(value);
});

// Quick-link chips populate the input and immediately navigate.
quickLinks.addEventListener("click", (event) => {
  const target = event.target.closest("button[data-url]");
  if (!target) return;
  input.value = target.dataset.url;
  navigate(target.dataset.url);
});

// Friendly first-load message once the controller is ready.
window.addEventListener("load", () => {
  clearStatus();
  setStatus("Ready. Enter a site or search term above.");
});
