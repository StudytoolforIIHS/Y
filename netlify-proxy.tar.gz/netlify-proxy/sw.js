/**
 * sw.js — Scramjet Service Worker
 * ============================================================================
 * This Service Worker is the heart of the proxy. It runs in the background of
 * the page's origin and intercepts every network request the proxied site
 * makes. Requests that belong to the Scramjet proxy namespace are handed off
 * to `scramjet.fetch()`, which rewrites + tunnels them through the configured
 * bare-mux transport (a Wisp/Bare WebSocket). Everything else falls through to
 * the normal network.
 *
 * It is fully client-side: `importScripts` pulls the Scramjet worker bundle
 * straight from jsDelivr, so no server build step is required and it works the
 * moment it is dropped onto Netlify.
 * ============================================================================
 */

"use strict";

// Pull the Scramjet "all" bundle (worker side) from the CDN.
// This defines the global `$scramjetLoadWorker()` factory used below.
importScripts(
  "https://cdn.jsdelivr.net/npm/@mercuryworkshop/scramjet@1.1.0/dist/scramjet.all.js"
);

// Instantiate the Scramjet service-worker runtime.
const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();

/**
 * Core request router.
 * 1. Loads (and caches) the Scramjet config that script.js published.
 * 2. If the request targets a Scramjet-controlled path, proxy it.
 * 3. Otherwise let it hit the network untouched.
 *
 * @param {FetchEvent} event
 * @returns {Promise<Response>}
 */
async function handleRequest(event) {
  await scramjet.loadConfig();

  if (scramjet.route(event)) {
    return scramjet.fetch(event);
  }

  return fetch(event.request);
}

// Activate immediately so the proxy is usable on first load without a reload.
self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Intercept and route every request.
self.addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event));
});
